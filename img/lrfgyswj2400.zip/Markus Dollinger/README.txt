...nachbelichtet Free Adobe Lightroom Presets
(C) Markus Dollinger

This archive contains 6 free Lightroom presets. Please feel free to use them as you like, you're allowed to redistribute the complete set as it is (with this README included). A backlink to my blog http://www.markus-dollinger.de would be nice. 

Description:

delicious food:
enhanced colors for food like meat, vegetables and fruits

dramatic_sky:
Adds high contrast and deep blues for landscapes, skies and clouds with a dramatic vignette

isolated blues:
isolates the blue colors and turns other colors to B/W

isolated greens:
the same but for - you guess it - the green colors

mystical landscapes:
turns the image into a spepia/blue splittoned B/W. Play around with the balance-slider (Split-Toning)!

punchy landscapes:
gives vibrant and strong colors to landscapes






 
